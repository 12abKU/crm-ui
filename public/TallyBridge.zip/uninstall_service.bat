@echo off
title Uninstall Inventive CRM Bridge
cd /d "%~dp0"
echo Stopping bridge process...
taskkill /F /IM TallyBridge.exe 2>nul
echo Removing from Windows startup...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "InventiveTallyBridge" /f >nul 2>&1
schtasks /delete /tn "InventiveTallyBridge" /f >nul 2>&1
echo.
echo ==========================================================
echo [SUCCESS] Inventive Tally Bridge has been uninstalled.
echo ==========================================================
pause
