# Inventive CRM - TallyPrime Desktop Bridge (Go Edition)

Standalone, ultra-lightweight Windows desktop agent (**11.4 MB single `.exe`**) connecting Inventive Cloud CRM to local TallyPrime (Port 9000).

## 🚀 Key Advantages for Clients
* **Zero Language or Runtime Installs:** The client PC does **NOT** need Go, Node.js, Python, or Java. Just give them `TallyBridge.exe`.
* **Premium Control Panel:** Double-clicking `TallyBridge.exe` opens a modern dark-mode control window with live status pills, configuration inputs, and instant connection testing.
* **1-Click Windows Background Service:** With one click, install the bridge as an automatic Windows Service that boots on PC startup and runs 24/7 without user intervention.
* **Offline ACID Resilience:** Uses an embedded pure-Go SQLite buffer (`modernc.org/sqlite` in WAL mode) to guarantee zero data loss during internet or Tally disconnects.
* **Strict FIFO Guarantee:** Ensures Sales Orders, Delivery Notes, and Sales Invoices execute in the exact manufacturing sequence.

---

## 🖥️ How It Works For Your Clients

1. Give the client `TallyBridge.exe`.
2. The client double-clicks `TallyBridge.exe`.
3. The **TallyPrime Desktop Connector** window opens:
   * **Cloud CRM Server URL:** e.g. `https://crm.yourcompany.com`
   * **Agent Secret Authentication Key:** Copied from CRM Settings
   * **Tally Company Name:** e.g. `Steel Dynamics`
   * **Tally Port:** `9000`
4. Click **⚡ Test Connection**:
   * Probes Tally on port 9000 and verifies connectivity.
   * Probes Cloud CRM with the secret key and verifies authentication.
5. Click **💾 Save Settings**.
6. Click **🚀 Install & Start Service**:
   * Registers `InventiveTallyBridge` as an automatic Windows Service.
   * Runs silently in the background on every PC boot!

---

## 🛠️ CLI Options (for IT Admins)

```powershell
# Probe local TallyPrime on port 9000
./TallyBridge.exe -test-tally

# Run one-off Finished Goods inventory sync and exit
./TallyBridge.exe -sync-inventory-only

# Run one-off customer balances & overdue aging sync and exit
./TallyBridge.exe -sync-balances-only

# Run headlessly as background service / daemon
./TallyBridge.exe -service
```

---

## 📁 Project Architecture
* `cmd/tallybridge/main.go` — Single entrypoint handling GUI mode, CLI flags, and Windows Service daemon mode.
* `internal/config/` — Self-managing JSON configuration (`config.json`).
* `internal/ui/` — Embedded modern desktop UI with live connection tester and service controls.
* `internal/tally/` — Port 9000 XML client with health checks and voucher response parser.
* `internal/crm/` — Cloud CRM client with long polling, FIFO ACKs, and telemetry heartbeats.
* `internal/buffer/` — Pure-Go SQLite WAL queue for offline resilience.
* `internal/mastersync/` — Master inventory & customer ledger aging background sync engine.
* `internal/service/` — Windows Service (`sc.exe`) management (install, start, stop, uninstall).
