@echo off
title Inventive CRM - TallyPrime Bridge
cd /d "%~dp0"
echo ==========================================================
echo    Inventive CRM - TallyPrime Desktop Bridge
echo ==========================================================
echo Starting bridge engine and desktop control panel...
echo UI will be open at http://127.0.0.1:9099
echo.
"%~dp0TallyBridge.exe"
