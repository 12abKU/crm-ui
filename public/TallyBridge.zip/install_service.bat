@echo off
title Install Inventive CRM Bridge Auto-Start
cd /d "%~dp0"
echo Registering Inventive CRM Tally Bridge for Windows Startup...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "InventiveTallyBridge" /t REG_SZ /d "\"%~dp0TallyBridge.exe\" --service" /f >nul
schtasks /create /tn "InventiveTallyBridge" /tr "\"%~dp0TallyBridge.exe\" --service" /sc onlogon /f >nul 2>&1
echo.
echo Starting background bridge service...
powershell -Command "Start-Process -FilePath '%~dp0TallyBridge.exe' -ArgumentList '--service' -WindowStyle Hidden"
echo.
echo ==========================================================
echo [SUCCESS] Inventive Tally Bridge installed and active!
echo It will automatically start whenever Windows boots.
echo Control panel: http://127.0.0.1:9099
echo ==========================================================
pause
