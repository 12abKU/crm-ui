@echo off
title Inventive CRM - TallyPrime Bridge
cd /d "%~dp0"
echo Starting Inventive CRM - TallyPrime Desktop Bridge...
.\TallyBridge.exe
pause
