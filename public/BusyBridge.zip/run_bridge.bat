@echo off
title Inventive CRM - BUSY ERP Desktop Bridge
cd /d "%~dp0"
echo ==========================================================
echo    Inventive CRM - BUSY ERP Desktop Bridge (Go Edition)
echo ==========================================================
echo Starting bridge in standalone console mode...
echo Probing Port 981 for local BUSY 21 instance...
echo.
"%~dp0BusyBridge.exe" -standalone
pause
