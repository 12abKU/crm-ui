@echo off
title Inventive CRM - BUSY ERP Bridge
cd /d "%~dp0"
echo Starting Inventive CRM - BUSY ERP Desktop Bridge...
.\BusyBridge.exe
pause
