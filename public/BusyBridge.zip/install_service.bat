@echo off
title Install Inventive BUSY Bridge Auto-Start Service
cd /d "%~dp0"
echo Registering Inventive CRM BUSY Bridge for Windows Startup...
"%~dp0BusyBridge.exe" -service-action install
echo.
pause
