@echo off
title Uninstall Inventive BUSY Bridge Service
cd /d "%~dp0"
echo Uninstalling Inventive CRM BUSY Bridge background service...
"%~dp0BusyBridge.exe" -service-action uninstall
echo.
pause
