# Inventive CRM - BUSY ERP Desktop Bridge (Go Edition)

Standalone, ultra-lightweight Windows desktop agent (**9.3 MB single `BusyBridge.exe`**) connecting Inventive Cloud CRM to local BUSY 21 / BUSY 18 accounting software running on Port 981.

---

## 🚀 Key Advantages
* **Zero Runtime Installs:** The client Windows machine does **NOT** require Go, Java, Python, Node.js, or Microsoft Access drivers. Zero CGO dependencies.
* **Direct Port 981 Client:** Communicates directly with local BUSY 21 via HTTP XML data exchange (`http://127.0.0.1:981/`).
* **Offline ACID Resilience:** Uses an embedded pure-Go SQLite buffer (`modernc.org/sqlite` in WAL mode) to guarantee zero data loss during network or ERP disconnects.
* **Strict FIFO Guarantee:** Ensures Order-to-Cash fulfillment vouchers (`Sales Order` -> `Sale Challan` -> `Sales Invoice`) execute in strict sequential order.
* **Dynamic Master Discovery:** Automatically scans and syncs 20+ inventory items, tax categories (CGST, SGST, IGST), HSN codes, and warehouse material centers (`Main Store`).
* **Native Windows Service Integration:** Can be installed and managed as a silent background Windows Service with 1 click or CLI flags.

---

## 🖥️ Quick Start Guide for Users / Clients

1. **Extract the Package:**
   Extract `BusyBridge.zip` to a folder on your Windows PC running BUSY ERP (e.g. `C:\BusyBridge`).

2. **Configure API Key & Server URL:**
   Open `config.json` in Notepad:
   ```json
   {
     "crmBaseUrl": "http://localhost:8080",
     "agentApiKey": "PASTE_YOUR_API_KEY_HERE",
     "busyHost": "127.0.0.1",
     "busyPort": 981,
     "busyCompanyName": "TATA MOTORS PASSENGER VEHICLES LIMITED",
     "busyCompanyCode": "COMP0001",
     "pollIntervalSec": 5,
     "heartbeatIntervalSec": 30,
     "inventorySyncIntervalMin": 5,
     "dbPath": "data/busy_agent.db"
   }
   ```
   * Replace `agentApiKey` with the API Key copied from **CRM Settings -> Accounting & ERP -> BUSY ERP**.
   * Verify `busyPort` is `981` and `busyCompanyName` matches the active company in BUSY.

3. **Verify Connectivity:**
   Open PowerShell or Command Prompt in the extracted folder and run:
   ```cmd
   BusyBridge.exe -test-busy
   BusyBridge.exe -test-crm
   ```

4. **Run the Bridge:**
   * **Console mode:** Double-click `run_bridge.bat` or run:
     ```cmd
     BusyBridge.exe -standalone
     ```
   * **Automatic Windows Service (Runs 24/7):** Double-click `install_service.bat` or run:
     ```cmd
     BusyBridge.exe -service-action install
     ```

---

## 🛠️ CLI Options (for System Administrators)

| Flag | Description |
|------|-------------|
| `-test-busy` | Test HTTP connectivity to local BUSY 21 on Port 981 |
| `-test-crm` | Test authentication and telemetry with Cloud CRM backend |
| `-sync-inventory-only` | Run one-off inventory & material center sync and exit |
| `-standalone` | Run in foreground console with verbose logging |
| `-service` | Run headlessly as background Windows Service daemon |
| `-service-action install` | Register daemon as automatic Windows startup service |
| `-service-action uninstall` | Unregister and stop background Windows service |
| `-service-action start` | Start the background service |
| `-service-action stop` | Stop the background service |
| `-service-action status` | Query current status of the background service |
| `-config <path>` | Specify custom configuration file path |
| `-port <port>` | Override BUSY port (default 981) |
| `-agent-key <key>` | Override CRM Agent API key |

---

## 📁 Package Contents

* `BusyBridge.exe` — Standalone Go binary (PE32+ AMD64, ~9.3 MB)
* `config.json` — Active configuration file
* `config.example.json` — Template reference configuration
* `run_bridge.bat` — Double-click batch script to launch foreground console bridge
* `install_service.bat` — Double-click batch script to install background Windows Service
* `uninstall_service.bat` — Double-click batch script to remove background Windows Service
* `README.md` — This documentation file
